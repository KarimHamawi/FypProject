import csv
import os
from datetime import datetime

# Specify the CSV file path
csv_file_path = r"C:\Users\PC\Desktop\Ghassan\UNI\FYP\FYP2\fromFYP1\fypCode\data1\events.csv"

# Ensure the directory exists
os.makedirs(os.path.dirname(csv_file_path), exist_ok=True)

# Utility function to read events from CSV and sort them
def read_and_sort_events():
    events = []
    if os.path.exists(csv_file_path):
        with open(csv_file_path, 'r', newline='', encoding='utf-8') as file:
            reader = csv.reader(file)
            events = list(reader)
    events.sort(key=lambda row: datetime(int(row[0]), int(row[1]), int(row[2]), int(row[3]), int(row[4])))
    return events

# Utility function to write events to CSV
def write_events(events):
    with open(csv_file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(events)

# Function to add a new event and automatically sort
def add_event(year, month, day, hour, minute, description):
    events = read_and_sort_events()
    events.append([year, month, day, hour, minute, description])
    events.sort(key=lambda row: datetime(int(row[0]), int(row[1]), int(row[2]), int(row[3]), int(row[4])))
    write_events(events)

# Function to delete an event by date and time
def delete_event(year, month, day, hour, minute):
    events = read_and_sort_events()
    events = [event for event in events if not (event[0] == str(year) and event[1] == str(month) and event[2] == str(day) and event[3] == str(hour) and event[4] == str(minute))]
    write_events(events)

