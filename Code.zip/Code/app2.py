import os
import pandas as pd
from datetime import datetime
from color_matching import color_matches
from model_training_and_evaluation import evaluate_model, make_recommendations
from flask import Flask, jsonify, request, render_template
from textToSpeech_api import text_to_speech
import json
import serial
import time
import pyttsx3

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, 'data1', 'Dataset-Copy.csv')

# Function to read and return the clothing dataset
def read_clothing_dataset():
    return pd.read_csv(CSV_PATH)

def filter_recommended_clothing_items(clothing_items, temperature, humidity, activity):
    recommended_items = []
    evaluate_model()
    for _, row in clothing_items.iterrows():
        raw_input_features = pd.DataFrame([{
            'Type': row['Type'],
            'Color': row['Color'],
            'Fabric': row['Fabric'],
            'Season Suitability': row['Season Suitability'],
            'Style': row['Style'],
            'Condition': row['Condition'],
            'Temp': temperature,
            'Weather Cond': 'Standard Weather',
            'Humidity': humidity,
            'Type of Event': activity
        }])
        
        recommended = make_recommendations(raw_input_features)
        if recommended[0] == 1:
            recommended_items.append(row)
    
    return pd.DataFrame(recommended_items)

def categorize_clothing_items(recommended_items):
    tops = recommended_items[recommended_items['Type'].isin(['Shirt', 'Dress', 'Jacket'])]
    bottoms = recommended_items[recommended_items['Type'].isin(['Trousers', 'Skirt'])]
    return tops, bottoms

def generate_color_matched_pairs(tops, bottoms):
    matching_pairs = []
    for _, top in tops.iterrows():
        for _, bottom in bottoms.iterrows():
            if color_matches(top['Color'], bottom['Color']):
                matching_pairs.append({
                    'Top': top['Id'],
                    'Bottom': bottom['Id']
                })
    return matching_pairs

def read_weather_from_arduino():
    arduino_port = 'COM5'  # Update this to your actual port if different
    baudrate = 9600
    timeout = 5

    try:
        with serial.Serial(arduino_port, baudrate, timeout=timeout) as ser:
            time.sleep(2)  # Allow time for Arduino to initialize
            print("Sending command to Arduino...")
            ser.write(b'R')
            ser.flush()  # Ensure the command is sent
            
            time.sleep(2)  # Wait a bit for the Arduino to process the command and respond
            
            line = ser.readline().decode('utf-8').strip()
            if line:
                print(f"Received data from Arduino: {line}")
                temperature, humidity = map(float, line.split(','))
                return temperature, humidity
            else:
                print("No data received from Arduino")
                return None
    except Exception as e:
        print(f"Failed to read from Arduino: {e}")
        return None

@app.route('/')
def home():
    clothing_df = read_clothing_dataset()
    return render_template('index2.html', clothing_items=clothing_df.to_dict(orient='records'))

@app.route('/add_clothing', methods=['POST'])
def add_clothing():
    clothing_df = read_clothing_dataset()
    try:
        data = request.get_json()
        if data is None:
            raise ValueError("No JSON data received")

        if clothing_df.empty or 'Id' not in clothing_df.columns:
            next_id = 1
        else:
            next_id = int(clothing_df['Id'].max()) + 1

        data['Id'] = next_id

        new_row = pd.DataFrame([data])
        clothing_df = pd.concat([clothing_df, new_row], ignore_index=True)
        clothing_df.to_csv(CSV_PATH, index=False)
        return jsonify({'success': True, 'message': 'Clothing added successfully', 'id': next_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Server error: {str(e)}"}), 500

@app.route('/get_clothing', methods=['GET'])
def get_clothing():
    clothing_df = read_clothing_dataset()
    return jsonify(clothing_df.to_dict(orient='records'))

@app.route('/delete_clothing/<int:item_id>', methods=['DELETE'])
def delete_clothing(item_id):
    clothing_df = read_clothing_dataset()
    try:
        if (clothing_df['Id'] == item_id).any():
            clothing_df = clothing_df[clothing_df['Id'] != item_id].reset_index(drop=True)
            clothing_df.to_csv(CSV_PATH, index=False)
            return jsonify({'success': True, 'message': 'Clothing item deleted'})
        else:
            raise KeyError("Item ID not found")
    except KeyError:
        return jsonify({'success': False, 'message': 'Item not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f"Server error: {str(e)}"}), 500

@app.route('/update_clothing', methods=['POST'])
def update_clothing():
    clothing_df = read_clothing_dataset()
    data = request.json
    item_id = int(data['Id'])
    try:
        row_index = clothing_df[clothing_df['Id'] == item_id].index[0]
        for key, value in data.items():
            if key != 'Id':
                clothing_df.at[row_index, key] = value
        clothing_df.to_csv(CSV_PATH, index=False)
        return jsonify({'success': True, 'message': 'Item updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/generate_outfits', methods=['POST'])
def generate_outfits_endpoint():
    try:
        data = request.json
        if not data:
            raise ValueError("No JSON data received")

        activity = data.get('activity')

        weather_data = read_weather_from_arduino()
        if not weather_data:
            return jsonify({"success": False, "message": "Failed to read weather data from Arduino."})
        
        temperature, humidity = weather_data
        clothing_items = read_clothing_dataset()

        recommended_items = filter_recommended_clothing_items(clothing_items, temperature, humidity, activity)
        tops, bottoms = categorize_clothing_items(recommended_items)
        matching_pairs = generate_color_matched_pairs(tops, bottoms)
        
        if matching_pairs:
            top_outfit = matching_pairs[0]
            formatted_outfit = format_outfit(top_outfit)
            send_to_arduino(formatted_outfit)
            
            # Add text-to-speech announcement
            text_to_speech(formatted_outfit)
            
            return jsonify({"success": True, "outfit": top_outfit})
        else:
            return jsonify({"success": False, "message": "No outfits generated."})
    except Exception as e:
        print(f"Error in generate_outfits_endpoint: {e}")
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500

def send_to_arduino(data):
    arduino_port = 'COM5'
    baudrate = 9600
    timeout = 1
    try:
        with serial.Serial(arduino_port, baudrate, timeout=timeout) as ser:
            ser.write(data.encode())
    except Exception as e:
        print(f"Failed to send data to Arduino: {e}")

def format_outfit(outfit):
    top = outfit.get("Top")
    bottom = outfit.get("Bottom")
    jacket = outfit.get("Jacket")
    dress = outfit.get("Dress")
    
    parts = []
    if top:
        parts.append(f"Top {top}")
    if bottom:
        parts.append(f"Bottom {bottom}")
    if jacket:
        parts.append(f"Jacket {jacket}")
    if dress:
        parts.append(f"Dress {dress}")
    
    return " and ".join(parts)

@app.route('/text_to_speech', methods=['POST'])
def text_to_speech_endpoint():
    data = request.json
    text = data.get('text', '')
    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', 170)
        engine.setProperty('volume', 1)
        engine.say(text)
        engine.runAndWait()
        return jsonify({'success': True, 'message': 'Text to speech succeeded'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Text to speech failed: {e}'})

if __name__ == '__main__':
    app.run(debug=True)
