def color_matches(top, bottom):
    color_matching_matrix = {
        'Black': ['White', 'Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Brown', 'Gray'],
        'White': ['Black', 'Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Brown', 'Gray'],
        'Red': ['Black', 'White', 'Blue', 'Yellow', 'Green', 'Gray'],
        'Blue': ['Black', 'White', 'Yellow', 'Green', 'Orange', 'Brown', 'Gray'],
        'Green': ['Black', 'White', 'Brown', 'Yellow', 'Blue', 'Gray'],
        'Yellow': ['Black', 'White', 'Blue', 'Red', 'Green', 'Gray'],
        'Purple': ['Black', 'White', 'Red', 'Blue', 'Gray'],
        'Orange': ['Black', 'White', 'Blue', 'Brown', 'Green', 'Gray'],
        'Brown': ['Black', 'White', 'Blue', 'Green', 'Orange', 'Yellow', 'Red', 'Gray'],
        'Gray': ['Black', 'White', 'Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Brown']
    }

    # Check if bottom color matches with top
    if bottom in color_matching_matrix[top]:
        return True
    else:
        return False


