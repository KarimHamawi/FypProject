import serial
import time

def get_sensor_data(com_port='COM5'):
    try:
        arduino_serial = serial.Serial(com_port, 9600)
        time.sleep(2)  # Wait for the serial connection to initialize

        arduino_serial.write(b'r')  # Command to read data
        time.sleep(2)  # Wait for data to be sent from Arduino

        data = {}
        if arduino_serial.in_waiting:
            raw_data = arduino_serial.readline().decode('utf-8').rstrip()
            temp_str, humidity_str = raw_data.split('Humidity:')
            temperature = float(temp_str.split(':')[1].strip().split(' ')[0])  # Extract temperature value
            humidity = float(humidity_str.strip().split(' ')[0])  # Extract humidity value
            data = {'temperature': temperature, 'humidity': humidity}
        
        arduino_serial.close()
        return data
    except Exception as e:
        print(f"Error reading from Arduino: {e}")
        return None
