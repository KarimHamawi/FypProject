document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("clothing-form").addEventListener("submit", function (event) {
        event.preventDefault();
        addClothingItem();
    });

    document.getElementById("generate-outfits").addEventListener("click", function () {
        generateOutfits();
    });

    function addClothingItem() {
        let formData = {
            Type: document.getElementById("type").value,
            Color: document.getElementById("color").value,
            Fabric: document.getElementById("fabric").value,
            'Season Suitability': document.getElementById("season").value,
            Style: document.getElementById("style").value,
            Condition: document.getElementById("condition").value
        };

        fetch('/add_clothing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                formData['Id'] = data.id;  // Use the Id returned from the server
                addClothingRow(formData); // Add row to table with the new ID
                alert(data.message);
            } else {
                alert('Failed to add clothing item: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
        document.getElementById("clothing-form").reset();
    }

    function addClothingRow(data) {
        let table = document.getElementById("clothing-table").querySelector("tbody");
        let row = document.createElement("tr");

        ["Id", "Type", "Color", "Fabric", "Season Suitability", "Style", "Condition"].forEach(field => {
            let cell = document.createElement("td");
            cell.textContent = data[field];
            row.appendChild(cell);
        });

        let actionCell = document.createElement("td");
        let editBtn = document.createElement("button");
        editBtn.textContent = "Edit";
        editBtn.onclick = function () {
            editClothingItem(row);
        };
        actionCell.appendChild(editBtn);

        let removeBtn = document.createElement("button");
        removeBtn.textContent = "Remove";
        removeBtn.onclick = function () {
            removeClothingItem(data['Id'], row);
        };
        actionCell.appendChild(removeBtn);

        row.appendChild(actionCell);
        table.appendChild(row);
    }

    function removeClothingItem(itemId, row) {
        fetch('/delete_clothing/' + itemId, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                row.remove();
                alert('Item removed successfully.');
            } else {
                alert('Failed to remove item: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    function editClothingItem(row) {
        const values = ["Id", "Type", "Color", "Fabric", "Season Suitability", "Style", "Condition"].map((field, index) => row.cells[index].textContent);
        const options = {
            Type: ["Jacket", "Dress", "Shirt", "Skirt", "Trousers"],
            Color: ["White", "Blue", "Black", "Red", "Green", "Yellow", "Orange", "Purple"],
            Fabric: ["Cotton", "Wool", "Polyester", "Silk"],
            'Season Suitability': ["Spring", "Summer", "Fall", "Winter"],
            Style: ["Casual", "Vintage", "Athletic", "Formal"],
            Condition: ["New", "Used", "Worn"]
        };

        openEditModal(options, values, row);
    }

    function openEditModal(options, values, row) {
        let modal = document.createElement("div");
        modal.style.position = "fixed";
        modal.style.top = "50%";
        modal.style.left = "50%";
        modal.style.transform = "translate(-50%, -50%)";
        modal.style.backgroundColor = "white";
        modal.style.padding = "20px";
        modal.style.zIndex = "1000";
        modal.style.width = "500px";
        modal.style.boxSizing = "border-box";
        modal.style.border = "1px solid #ccc";
        modal.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.1)";

        let formHtml = `<form id="edit-form">
            <input type="hidden" name="Id" value="${values[0]}">`;  // Hidden field for the ID
        Object.keys(options).forEach((field, index) => {
            formHtml += createSelectHTML(field, options[field], values[index + 1]);
        });
        formHtml += `<button type="button" onclick="submitEdit(this.form, ${row.rowIndex})">Save Changes</button>
                     <button type="button" onclick="this.closest('div').remove()">Cancel</button>
                     </form>`;

        modal.innerHTML = formHtml;
        document.body.appendChild(modal);
    }

    function createSelectHTML(name, options, selectedValue) {
        let optionsHTML = options.map(option =>
            `<option value="${option}" ${option === selectedValue ? 'selected' : ''}>${option}</option>`
        ).join('');

        return `<label>${name.charAt(0).toUpperCase() + name.slice(1)}: 
                <select name="${name}">${optionsHTML}</select>
                </label><br>`;
    }

    window.submitEdit = function (form, rowIndex) {
        let table = document.getElementById("clothing-table");
        let row = table.rows[rowIndex];
        let selects = form.querySelectorAll("select");
        let updatedData = {
            Id: form.querySelector('input[name="Id"]').value  // Keep the same Id
        };

        Array.from(selects).forEach((select, index) => {
            let fieldName = select.name;
            updatedData[fieldName] = select.value;
            row.cells[index + 1].textContent = select.value; // Update the table cell text
        });

        fetch('/update_clothing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Update successful');
            } else {
                console.error('Failed to update', data.message);
            }
        })
        .catch(error => console.error('Error updating item', error));

        document.body.removeChild(form.parentNode);
    };

    function generateOutfits() {
        let activity = document.getElementById("activity").value;

        fetch('/generate_outfits', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ activity: activity }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`Generated outfit: Top ${data.outfit.Top} and Bottom ${data.outfit.Bottom}`);
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    // Fetch clothing items once the page is fully loaded and populate the table
    fetch('/get_clothing')
        .then(response => response.json())
        .then(data => {
            data.forEach(item => addClothingRow(item));
        })
        .catch(error => console.error('Error fetching clothing items:', error));
});
