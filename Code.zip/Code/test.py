import serial
import time

def test_serial_communication():
    try:
        arduino = serial.Serial('COM5', 9600, timeout=1)  # Replace 'COM3' with your Arduino port
        time.sleep(2)  # Wait for the serial connection to initialize
        test_message = '{"Dress": "21", "Jacket": "38", "Top": "15", "Bottom": "34"}'
        print(f"Sending to Arduino: {test_message}")
        arduino.write(test_message.encode('utf-8'))
        arduino.close()
    except Exception as e:
        print(f"Failed to send data to Arduino: {e}")

if __name__ == '__main__':
    test_serial_communication()
