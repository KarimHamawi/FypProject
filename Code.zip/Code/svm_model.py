import pandas as pd
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import joblib
from data_preprocessing import load_data, preprocess_data, preprocessor, get_feature_names

def train_optimized_svm(X_train, y_train, model_path='optimized_svm_model.pkl'):
    """Train an SVM classifier with specified hyperparameters."""
    # Initialize the SVM classifier with predefined optimal parameters
    svm_classifier = SVC(C=1, class_weight=None, gamma=0.1, kernel='poly')
    svm_classifier.fit(X_train, y_train)  # Train the model
    joblib.dump(svm_classifier, model_path)  # Save the model to disk for later use
    return svm_classifier

def evaluate_model():
    """Evaluate the SVM model, print the classification report and accuracy."""
    data = load_data()  # Load the dataset
    X, y = preprocess_data(data, 'Recommend')  # Preprocess the data for SVM
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  # Split data

    model = train_optimized_svm(X_train, y_train)  # Train the model

    joblib.dump(preprocessor, 'preprocessor.pkl')  # Save the preprocessor for later use

    predictions = model.predict(X_test)  # Make predictions on the test set

    # Print classification report and confusion matrix
    print("Classification Report:\n", classification_report(y_test, predictions, output_dict=True))
    print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
    print("Accuracy:", accuracy_score(y_test, predictions))  # Print accuracy

def make_recommendations(raw_input_features):
    """Make predictions using the trained SVM model based on input features."""
    model = joblib.load('optimized_svm_model.pkl')  # Load the trained SVM model
    preprocessor = joblib.load('preprocessor.pkl')  # Load the preprocessor

    # Process the features using the preprocessor
    input_features = preprocessor.transform(raw_input_features)
    feature_names = get_feature_names(preprocessor)

    # Convert processed features into a DataFrame for prediction
    input_features_df = pd.DataFrame(input_features.toarray(), columns=feature_names)
    recommendation = model.predict(input_features_df)  # Predict using the SVM model
    return recommendation

if __name__ == "__main__":
    evaluate_model()  # Execute the evaluation function when the script runs
