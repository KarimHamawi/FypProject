import os
import sys
from urllib.request import urlopen

def internet_on():
    try:
        urlopen('https://www.google.com', timeout=1)  # Google's IP
        return True
    except:
        return False

if internet_on():
    print("Internet detected. Running standard recommendation engine.")
    os.system('python clothing_recommendation_engine.py')
else:
    print("No Internet detected. Running recommendation engine with Arduino data.")
    from arduino_sensor_reader import get_sensor_data
    sensor_data = get_sensor_data()  # Default COM port is COM5, change if necessary
    if sensor_data:
        os.environ['TEMPERATURE'] = str(sensor_data['temperature'])
        os.environ['HUMIDITY'] = str(sensor_data['humidity'])
        os.system('python clothing_recommendation_engine_arduino.py')
    else:
        print("Failed to get sensor data. Check your Arduino connection.")
