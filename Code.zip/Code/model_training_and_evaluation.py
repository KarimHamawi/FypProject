import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
import joblib
from data_preprocessing import load_data, preprocess_data, preprocessor, get_feature_names

# Function to train the K-Nearest Neighbors model with predefined optimal parameters
def train_model(X_train, y_train):
    # Initializing the KNN model with specific parameters found via GridSearch
    knn = KNeighborsClassifier(n_neighbors=15, weights='distance', metric='manhattan')
    knn.fit(X_train, y_train)  # Training the model
    joblib.dump(knn, 'trained_knn_model.pkl')  # Saving the trained model to disk
    return knn

# Function to evaluate the trained KNN model
def evaluate_model():
    # Loading and preprocessing the dataset
    data = load_data()
    X, y = preprocess_data(data, 'Recommend')
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Training the model using the train dataset
    model = train_model(X_train, y_train)

    # Saving the preprocessor object after it's been fitted to the data
    joblib.dump(preprocessor, 'preprocessor.pkl')

    # Making predictions on the test dataset
    predictions = model.predict(X_test)

    # Generating and printing the classification report
    classification_report_dict = classification_report(y_test, predictions, output_dict=True)
    print("Classification Report:")
    for key, value in classification_report_dict.items():
        print(f"{key}: {value}")

    # Generating and printing the confusion matrix
    confusion_matrix_arr = confusion_matrix(y_test, predictions).tolist()
    print("Confusion Matrix:\n", confusion_matrix_arr)
    
    # Calculating and printing the ROC-AUC score if the data is binary
    if len(set(y)) == 2:
        prob_predictions = model.predict_proba(X_test)[:, 1]
        roc_auc = roc_auc_score(y_test, prob_predictions)
        print("ROC-AUC Score:", roc_auc)
    
    # Calculating and printing cross-validation scores
    cv_scores = cross_val_score(model, X, y, cv=5)
    print("Cross-Validation Scores:", cv_scores)
    print("Average CV Score:", cv_scores.mean())

# Function to make recommendations using the trained KNN model
def make_recommendations(raw_input_features):
    # Loading the trained model and the preprocessor
    model = joblib.load('trained_knn_model.pkl')
    preprocessor = joblib.load('preprocessor.pkl')

    # Applying the preprocessor to the input features and creating a DataFrame
    input_features = preprocessor.transform(raw_input_features)
    feature_names = get_feature_names(preprocessor)
    input_features_df = pd.DataFrame(input_features.toarray(), columns=feature_names)
    
    # Making and returning predictions
    recommendation = model.predict(input_features_df)
    return recommendation

# Main execution block to evaluate the model
if __name__ == "__main__":
    accuracy_result = evaluate_model()

    
# if __name__ == "__main__":
#     evaluation_results = evaluate_model()
#     print("Evaluation Results:", evaluation_results)
    
#     raw_input_features = pd.DataFrame([{
#     'Type': 'Jacket',
#     'Color': 'Green',
#     'Fabric': 'Wool',
#     'Season Suitability': 'Spring',
#     'Style': 'Vintage',
#     'Condition': 'New',
#     'Temp': 15,
#     'Weather Cond': 'Standard Weather',
#     'Humidity': 61,
#     'Type of Event': 'Formal Event',
# }])

# recommendation = make_recommendations(raw_input_features)
# print("Recommendation for the sample input:", recommendation)