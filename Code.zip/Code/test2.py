import serial
import time

def read_weather_from_arduino():
    arduino_port = 'COM5'  # Ensure this is the correct port
    baudrate = 9600
    timeout = 5  # Reasonable timeout to wait for the response

    try:
        with serial.Serial(arduino_port, baudrate, timeout=timeout) as ser:
            time.sleep(2)  # Allow time for Arduino to initialize
            print("Sending command to Arduino...")
            ser.write(b'R')
            ser.flush()  # Ensure the command is sent
            
            time.sleep(2)  # Wait a bit for the Arduino to process the command and respond
            
            line = ser.readline().decode('utf-8').strip()
            if line:
                print(f"Received data from Arduino: {line}")
                temperature, humidity = map(float, line.split(','))
                return temperature, humidity
            else:
                print("No data received from Arduino")
                return None
    except Exception as e:
        print(f"Failed to read from Arduino: {e}")
        return None

# Test the function
if __name__ == "__main__":
    weather_data = read_weather_from_arduino()
    if weather_data:
        print(f"Temperature: {weather_data[0]}, Humidity: {weather_data[1]}")
    else:
        print("Failed to read weather data from Arduino.")
