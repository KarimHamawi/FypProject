import pandas as pd
from datetime import datetime
import clothing_recommendation_engine
from flask import Flask, jsonify, request, render_template

app = Flask(__name__)
CSV_PATH = '../data1/Dataset-Copy.csv'  
# EVENTS_CSV_PATH = '../data1/events.csv'

def load_clothing_items():
    try:
        return pd.read_csv(CSV_PATH)
    except Exception as e:
        print(f"Error reading the CSV file: {e}")
        return pd.DataFrame()  # Return an empty DataFrame if there's an error

def save_clothing_items(df):
    try:
        df.to_csv(CSV_PATH, index=False)  # Save without the index to avoid extra columns
    except Exception as e:
        print(f"Error writing to the CSV file: {e}")

# Load clothing items into a DataFrame
clothing_df = load_clothing_items()

events = []  # Store calendar events

@app.route('/')
def home():
    # Convert DataFrame to list of dicts for the frontend
    return render_template('index1.html', clothing_items=clothing_df.to_dict(orient='records'))

# Endpoint for adding clothing items
@app.route('/add_clothing', methods=['POST'])
def add_clothing():
    global clothing_df
    try:
        data = request.get_json()  # Make sure to use get_json to properly parse incoming JSON data
        if data is None:
            raise ValueError("No JSON data received")

        if clothing_df.empty or 'Id' not in clothing_df.columns:
            next_id = 1
        else:
            next_id = int(clothing_df['Id'].max()) + 1  # Ensure ID is an integer

        data['Id'] = next_id  # Assign the next Id to the new item

        new_row = pd.DataFrame([data])
        clothing_df = pd.concat([clothing_df, new_row], ignore_index=True)
        save_clothing_items(clothing_df)
        return jsonify({'success': True, 'message': 'Clothing added successfully', 'id': next_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Server error: {str(e)}"}), 500

# Endpoint for retrieving all clothing items
@app.route('/get_clothing', methods=['GET'])
def get_clothing():
    return jsonify(clothing_df.to_dict(orient='records'))

@app.route('/delete_clothing/<int:item_id>', methods=['DELETE'])
def delete_clothing(item_id):
    global clothing_df
    try:
        # Check if the item exists and drop it
        if item_id in clothing_df['Id'].values:
            clothing_df = clothing_df[clothing_df['Id'] != item_id].reset_index(drop=True)
            save_clothing_items(clothing_df)
            return jsonify({'success': True, 'message': 'Clothing item deleted'})
        else:
            raise KeyError("Item ID not found")
    except KeyError:
        return jsonify({'success': False, 'message': 'Item not found'}), 404

@app.route('/update_clothing', methods=['POST'])
def update_clothing():
    global clothing_df
    data = request.json
    item_id = int(data['Id'])
    try:
        row_index = clothing_df[clothing_df['Id'] == item_id].index[0]
        for key, value in data.items():
            if key != 'Id':  # Avoid updating the ID
                clothing_df.at[row_index, key] = value
        save_clothing_items(clothing_df)
        return jsonify({'success': True, 'message': 'Item updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

EVENTS_CSV_PATH = '../data1/events.csv'

def load_events():
    try:
        df = pd.read_csv(EVENTS_CSV_PATH)
        # Convert the date and time columns into a datetime format FullCalendar can use
        df['start'] = pd.to_datetime(df[['year', 'month', 'day', 'hour', 'minute']])
        # Convert dataframe to dictionary format for JSON serialization
        events = df[['description', 'start']].to_dict(orient='records')
        return events
    except Exception as e:
        print(f"Error loading events: {e}")
        return []

@app.route('/api/events', methods=['GET'])
def get_events():
    events = load_events()
    return jsonify(events)


def save_events(events_df):
    try:
        events_df.to_csv(EVENTS_CSV_PATH, index=False)
        print("Events saved successfully")  # Debug print
    except Exception as e:
        print(f"Failed to save events: {e}")

@app.route('/add_event', methods=['POST'])
def add_event():
    event = request.json
    try:
        # Parse ISO 8601 format correctly
        event_datetime = datetime.fromisoformat(event['start'].rstrip('Z'))
        new_event = pd.DataFrame([{
            'year': event_datetime.year,
            'month': event_datetime.month,
            'day': event_datetime.day,
            'hour': event_datetime.hour,
            'minute': event_datetime.minute,
            'description': event['title']
        }])
        # Load events, append new event using concat, and save
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        events_df = pd.concat([events_df, new_event], ignore_index=True)
        events_df.to_csv(EVENTS_CSV_PATH, index=False)
        return jsonify({'success': True, 'message': 'Event added successfully'})
    except Exception as e:
        print(f"Failed to add event: {e}")
        return jsonify({'success': False, 'message': f"Failed to add event: {str(e)}"})

@app.route('/update_event', methods=['POST'])
def update_event():
    event = request.json
    try:
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        # Finding the correct event to update
        mask = events_df['description'] == event['oldTitle']
        if mask.any():
            events_df.loc[mask, 'description'] = event['title']
            events_df.to_csv(EVENTS_CSV_PATH, index=False)
            return jsonify({'success': True, 'message': 'Event updated successfully'})
        else:
            return jsonify({'success': False, 'message': 'Event not found'})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Failed to update event: {str(e)}"})

@app.route('/delete_event', methods=['POST'])
def delete_event():
    event = request.json
    try:
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        initial_length = len(events_df)
        events_df = events_df[events_df['description'] != event['title']]
        if len(events_df) < initial_length:
            events_df.to_csv(EVENTS_CSV_PATH, index=False)
            return jsonify({'success': True, 'message': 'Event deleted successfully'})
        else:
            return jsonify({'success': False, 'message': 'Event not found'})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Failed to delete event: {str(e)}"})
    
@app.route('/generate_outfits', methods=['POST'])
def generate_outfits():
    data = request.get_json()
    event_description = data['event_description']
    clothing_data = pd.read_csv(CSV_PATH)  # Assuming the clothing data is stored in CSV_PATH
    
    # Call the recommendation engine function
    recommendations = clothing_recommendation_engine.generate_recommendations(event_description, clothing_data)
    
    return jsonify(recommendations)

if __name__ == '__main__':
    app.run(debug=True)