import os
import pandas as pd
from datetime import datetime
from color_matching import color_matches
from model_training_and_evaluation import evaluate_model, make_recommendations
import itertools

# Function to read and return the clothing dataset
def read_clothing_dataset():
    dataset_path = r'C:\Users\PC\Desktop\Ghassan\UNI\FYP\FYP2\fromFYP1\fypCode\data1\Dataset-Copy.csv'
    with open(dataset_path, 'r') as file:
        reader = pd.read_csv(file)  # Changed to pandas for convenience
    return reader

# Function to filter recommended clothing items
def filter_recommended_clothing_items(clothing_items, temperature, humidity, activity):
    recommended_items = []
    evaluate_model()
    for _, row in clothing_items.iterrows():
        raw_input_features = pd.DataFrame([{
            'Type': row['Type'],
            'Color': row['Color'],
            'Fabric': row['Fabric'],
            'Season Suitability': row['Season Suitability'],
            'Style': row['Style'],
            'Condition': row['Condition'],
            'Temp': temperature,
            'Weather Cond': 'Standard Weather',
            'Humidity': humidity,
            'Type of Event': activity
        }])
        
        recommended = make_recommendations(raw_input_features)
        if recommended[0] == 1:
            recommended_items.append(row)
    
    return pd.DataFrame(recommended_items)

# Function to categorize clothing items
def categorize_clothing_items(recommended_items):
    tops = recommended_items[recommended_items['Type'].isin(['Shirt', 'Dress', 'Jacket'])]
    bottoms = recommended_items[recommended_items['Type'].isin(['Trousers', 'Skirt'])]
    return tops, bottoms

# Function to generate color-matched pairs
def generate_color_matched_pairs(tops, bottoms):
    matching_pairs = []
    for _, top in tops.iterrows():
        for _, bottom in bottoms.iterrows():
            if color_matches(top['Color'], bottom['Color']):
                matching_pairs.append({
                    'Top': top['Id'],
                    'Bottom': bottom['Id']
                })
    return matching_pairs

if __name__ == '__main__':
    temperature = float(os.environ.get('TEMPERATURE', '20'))  # Default to 20 C if not set
    humidity = float(os.environ.get('HUMIDITY', '50'))  # Default to 50% if not set

    clothing_items = read_clothing_dataset()
    recommended_items = filter_recommended_clothing_items(clothing_items, temperature, humidity, "Casual Outing")
    print(recommended_items)
    tops, bottoms = categorize_clothing_items(recommended_items)
    matching_pairs = generate_color_matched_pairs(tops, bottoms)
    print("Matching pairs based on color:", matching_pairs)