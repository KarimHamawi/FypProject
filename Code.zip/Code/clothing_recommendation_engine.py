import pandas as pd
from datetime import datetime
import joblib
import json
import os
from color_matching import color_matches
from openAI_api import classify_event_with_gpt3, classify_event_with_gpt3_2
import model_training_and_evaluation
import svm_model 
import naive_bayes_model
from openWeather_api import get_weather_data

def read_clothing_dataset():
    """Load the clothing dataset from a specified file path."""
    dataset_path = r'C:\Users\PC\Desktop\Data Science Project\Code\data1\Dataset-Copy.csv'
    return pd.read_csv(dataset_path)

def get_and_classify_todays_events():
    """Retrieve and classify events for the current day."""
    events_file_path = r'C:\Users\PC\Desktop\Data Science Project\Code\data1\events.csv'
    today = datetime.now().date()
    todays_events_with_classification = []
    with open(events_file_path, 'r') as file:
        events = pd.read_csv(file)
        for _, event in events.iterrows():
            event_date = datetime.strptime(f"{event['year']}-{event['month']}-{event['day']}", '%Y-%m-%d').date()
            if event_date == today:
                classification = classify_event_with_gpt3(event['description'])
                event['classification'] = classification
                todays_events_with_classification.append(event)
    return todays_events_with_classification

def score_outfit(outfit, clothing_df):
    score = 0
    # Weight for each criterion
    color_weight = 1
    season_weight = 3
    style_weight = 5
    condition_weight = 4

    items = [clothing_df.loc[clothing_df['Id'] == item_id].iloc[0] for item_id in outfit.values()]
    
    # Color matching score
    if 'Top' in outfit and 'Bottom' in outfit:
        if color_matches(items[0]['Color'], items[1]['Color']):
            score += color_weight

    # Season suitability score
    current_season = 'Spring'  # You can change this to dynamically get the current season
    for item in items:
        if item['Season Suitability'] == current_season:
            score += season_weight

    # Style matching score
    styles = set(item['Style'] for item in items)
    if len(styles) == 1:  # All items have the same style
        score += style_weight

    # Condition score
    for item in items:
        if item['Condition'] == 'New':
            score += condition_weight
        elif item['Condition'] == 'Used':
            score += condition_weight / 2
        elif item['Condition'] == 'Worn':
            score += condition_weight / 4

    return score

def filter_recommended_clothing_items(clothing_items, event_descriptions, city_name):
    """Filter and recommend clothing items based on the current weather and a specific event."""
    try:
        with open("city.list.json", "r", encoding='utf-8') as file:
            city_list = json.load(file)
        city_info = next(city for city in city_list if city["name"].lower() == city_name.lower())
        country_code = city_info["country"]
    except StopIteration:
        print("City not found in the list. Please check the city name and try again.")
        return None
    except FileNotFoundError:
        print("City list file not found. Please ensure the 'city.list.json' file is present.")
        return None
    
    recommended_items = []
    weather_data = get_weather_data(city_name, country_code)
    weather_cond = classify_event_with_gpt3_2(str(weather_data[0]))

    for _, row in clothing_items.iterrows():
        for event_description in event_descriptions:
            # Check if the event classification is cached
            event_classification = classify_event_with_gpt3(event_description)

            raw_input_features = pd.DataFrame([{
                'Type': row['Type'],
                'Color': row['Color'],
                'Fabric': row['Fabric'],
                'Season Suitability': row['Season Suitability'],
                'Style': row['Style'],
                'Condition': row['Condition'],
                'Temp': int(weather_data[2] - 273.15),
                'Weather Cond': str(weather_cond),
                'Humidity': int(weather_data[4]),
                'Type of Event': str(event_classification)
            }])
            recommended = svm_model.make_recommendations(raw_input_features)
            if recommended[0] == 1:
                recommended_items.append(row)
    return pd.DataFrame(recommended_items)


def categorize_clothing_items(recommended_items):
    """Categorize recommended items into dresses, jackets, tops, and bottoms."""
    dresses = recommended_items[recommended_items['Type'] == 'Dress']
    jackets = recommended_items[recommended_items['Type'] == 'Jacket']
    tops = recommended_items[recommended_items['Type'].isin(['Shirt'])]
    bottoms = recommended_items[recommended_items['Type'].isin(['Trousers', 'Skirt'])]
    return dresses, jackets, tops, bottoms

def normalize_json_string(json_str):
    """Normalize a JSON string by loading it and dumping it with sorted keys."""
    return json.dumps(json.loads(json_str), sort_keys=True)

def generate_outfits(dresses, jackets, tops, bottoms, clothing_df, excluded_outfits_csv_path, chosen_outfits_csv_path):
    outfits = []
    accepted_garments = []  # Store accepted garments for output

    # Generate outfits
    for _, dress in dresses.iterrows():
        outfit = {'Dress': dress['Id']}
        accepted_garments.append(dress)
        for _, jacket in jackets.iterrows():
            if color_matches(dress['Color'], jacket['Color']):
                outfit['Jacket'] = jacket['Id']
                accepted_garments.append(jacket)
        outfits.append(outfit)

    for _, top in tops.iterrows():
        for _, bottom in bottoms.iterrows():
            if color_matches(top['Color'], bottom['Color']):
                outfit = {'Top': top['Id'], 'Bottom': bottom['Id']}
                accepted_garments.append(top)
                accepted_garments.append(bottom)
                for _, jacket in jackets.iterrows():
                    if color_matches(top['Color'], jacket['Color']):
                        outfit['Jacket'] = jacket['Id']
                        accepted_garments.append(jacket)
                outfits.append(outfit)

    # Debugging: Print generated outfits before exclusion
    print("Generated Outfits:", [json.dumps(outfit) for outfit in outfits])

    # Exclude outfits that are in the excluded outfits CSV
    if os.path.exists(excluded_outfits_csv_path):
        excluded_df = pd.read_csv(excluded_outfits_csv_path)
        excluded_outfits = set(excluded_df['outfit'].apply(normalize_json_string))
        # Debugging: Print excluded outfits
        print("Excluded Outfits from CSV:", excluded_outfits)
        outfits = [outfit for outfit in outfits if normalize_json_string(json.dumps(outfit)) not in excluded_outfits]

    # Exclude outfits that have been chosen 5 or more times
    if os.path.exists(chosen_outfits_csv_path):
        chosen_df = pd.read_csv(chosen_outfits_csv_path)
        chosen_df = chosen_df[chosen_df['count'] >= 5]
        excluded_chosen_outfits = set(chosen_df['outfit'].apply(normalize_json_string))
        # Debugging: Print outfits excluded due to being chosen 5+ times
        print("Outfits excluded due to being chosen 5+ times:", excluded_chosen_outfits)
        outfits = [outfit for outfit in outfits if normalize_json_string(json.dumps(outfit)) not in excluded_chosen_outfits]

    # Debugging: Print outfits after exclusion
    print("Outfits after exclusion:", [json.dumps(outfit) for outfit in outfits])

    # Score the outfits
    scored_outfits = [(outfit, score_outfit(outfit, clothing_df)) for outfit in outfits]
    # Sort by score in descending order
    scored_outfits.sort(key=lambda x: x[1], reverse=True)
    # Get the top 5 outfits
    top_outfits = [outfit for outfit, score in scored_outfits[:5]]

    accepted_garments_df = pd.DataFrame(accepted_garments).drop_duplicates()
    accepted_garments_df = accepted_garments_df.sort_values(by='Id')
    print("\nAccepted Garments for Matching:\n", accepted_garments_df)
    return top_outfits


