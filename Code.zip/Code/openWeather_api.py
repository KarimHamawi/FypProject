import requests
import json
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class WeatherAPIError(Exception):
    """Custom exception for Weather API errors."""
    pass

@retry(wait=wait_exponential(multiplier=1, min=1, max=10), stop=stop_after_attempt(5), retry=retry_if_exception_type((requests.exceptions.RequestException, WeatherAPIError)))
def get_city_info(city_name, country, city_list):
    for city in city_list:
        if city['name'] == city_name and city['country'] == country:
            return city['coord']  # Return the coordinates dictionary
    raise WeatherAPIError("City not found in the list.")

@retry(wait=wait_exponential(multiplier=1, min=1, max=10), stop=stop_after_attempt(5), retry=retry_if_exception_type((requests.exceptions.RequestException, WeatherAPIError)))
def get_weather_data(city_name, country):
    with open('city.list.json', encoding='utf-8') as f:
        city_list = json.load(f)
    
    api_key = 'f46757c69f835586f8c7765a3c510cc9'
    coord = get_city_info(city_name, country, city_list)
    if not coord:
        raise WeatherAPIError(f"City {city_name} not found in country {country}.")

    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    complete_url = f"{base_url}appid={api_key}&lat={coord['lat']}&lon={coord['lon']}"
    
    logging.info(f"Requesting weather data for {city_name}, {country} with URL: {complete_url}")
    response = requests.get(complete_url)
    response.raise_for_status()  # Raise an HTTPError for bad responses
    
    weather_data = response.json()
    
    if weather_data['cod'] == 200:
        main_weather = weather_data['weather'][0]['main']
        description = weather_data['weather'][0]['description']
        temperature = weather_data['main']['temp']
        pressure = weather_data['main']['pressure']
        humidity = weather_data['main']['humidity']
        
        # Return the weather data as an array
        return [main_weather, description, temperature, pressure, humidity]
    else:
        raise WeatherAPIError(f"Error from weather API: {weather_data.get('message', 'Unknown error')}")

# Example usage:
if __name__ == "__main__":
    try:
        weather = get_weather_data("Beirut", "LB")
        print("Weather data:", weather)
    except Exception as e:
        logging.error(f"Failed to get weather data: {e}")
