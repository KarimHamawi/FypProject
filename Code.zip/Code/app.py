import pandas as pd
from datetime import datetime
from clothing_recommendation_engine import filter_recommended_clothing_items, categorize_clothing_items, read_clothing_dataset, generate_outfits
from flask import Flask, jsonify, request, render_template
from textToSpeech_api import text_to_speech
import os
import openai
import logging
import json
import serial
import time
import sys

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = 'data1/Dataset-Copy.csv'
EXCLUDED_OUTFITS_CSV_PATH = 'data1/excluded_outfits.csv'
CHOSEN_OUTFITS_CSV_PATH = 'data1/chosen_outfits.csv'

def load_clothing_items():
    try:
        df = pd.read_csv(CSV_PATH)
        print(f"Loaded clothing items: {df.shape[0]} rows")  # Debugging statement
        return df
    except Exception as e:
        print(f"Error reading the CSV file: {e}")
        return pd.DataFrame()

def save_clothing_items(df):
    try:
        df.to_csv(CSV_PATH, index=False)
    except Exception as e:
        print(f"Error writing to the CSV file: {e}")

# Load clothing items into a DataFrame
clothing_df = load_clothing_items()

events = []  # Store calendar events

def save_chosen_outfit(outfit, chosen_outfits_csv_path):
    try:
        print("Saving chosen outfit...")
        os.makedirs(os.path.dirname(chosen_outfits_csv_path), exist_ok=True)
        
        if os.path.exists(chosen_outfits_csv_path):
            print("File exists. Reading...")
            df = pd.read_csv(chosen_outfits_csv_path)
        else:
            print("File does not exist. Creating new DataFrame...")
            df = pd.DataFrame(columns=['outfit', 'count'])

        outfit_str = json.dumps(outfit)
        if outfit_str in df['outfit'].values:
            df.loc[df['outfit'] == outfit_str, 'count'] += 1
        else:
            new_row = pd.DataFrame([{'outfit': outfit_str, 'count': 1}])
            df = pd.concat([df, new_row], ignore_index=True)

        print("Writing to CSV...")
        df.to_csv(chosen_outfits_csv_path, index=False)
        print(f"Saved chosen outfit: {outfit_str}")
        return df  # Return the updated DataFrame
    except Exception as e:
        print(f"Error saving chosen outfit: {e}")
        return None

def save_excluded_outfit(outfit, excluded_outfits_csv_path):
    try:
        os.makedirs(os.path.dirname(excluded_outfits_csv_path), exist_ok=True)
        
        if os.path.exists(excluded_outfits_csv_path):
            df = pd.read_csv(excluded_outfits_csv_path)
        else:
            df = pd.DataFrame(columns=['outfit'])
        
        outfit_str = json.dumps(outfit)
        if outfit_str not in df['outfit'].values:
            new_row = pd.DataFrame([{'outfit': outfit_str}])
            df = pd.concat([df, new_row], ignore_index=True)
        
        df.to_csv(excluded_outfits_csv_path, index=False)
        print(f"Saved excluded outfit: {outfit_str}")
    except Exception as e:
        print(f"Error saving excluded outfit: {e}")

@app.route('/')
def home():
    return render_template('index1.html', clothing_items=clothing_df.to_dict(orient='records'))

@app.route('/generate_top_outfit', methods=['POST'])
def generate_top_outfit_endpoint():
    try:
        data = request.json
        if not data:
            raise ValueError("No JSON data received")

        event_descriptions = data.get('event_descriptions')
        city_name = data.get('city_name', 'Beirut')

        logging.info(f"Event Descriptions: {event_descriptions}")
        logging.info(f"City Name: {city_name}")

        # Load clothing dataset
        clothing_items = read_clothing_dataset()
        logging.info("Clothing items loaded")

        # Filter recommended clothing items
        recommended_items = filter_recommended_clothing_items(clothing_items, event_descriptions, city_name)
        if recommended_items is None or recommended_items.empty:
            return jsonify({"success": False, "message": "No recommendations found."})

        logging.info("Recommended items found")

        # Categorize clothing items
        dresses, jackets, tops, bottoms = categorize_clothing_items(recommended_items)
        logging.info("Categorized clothing items")

        # Generate outfits and get the top 5
        top_outfits = generate_outfits(dresses, jackets, tops, bottoms, clothing_items, EXCLUDED_OUTFITS_CSV_PATH, CHOSEN_OUTFITS_CSV_PATH)
        logging.info("Generated top outfits")

        # Return the top 1 outfit
        if top_outfits:
            top_outfit = top_outfits[0]
            return jsonify({"success": True, "top_outfit": top_outfit})
        else:
            return jsonify({"success": False, "message": "No outfits generated."})
    except openai.error.RateLimitError as e:
        logging.error(f"Rate limit error: {e}")
        return jsonify({"success": False, "message": "Rate limit exceeded. Please try again later."}), 429
    except Exception as e:
        logging.error(f"Error in generate_top_outfit_endpoint: {e}")
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500

# Endpoint for adding clothing items
@app.route('/add_clothing', methods=['POST'])
def add_clothing():
    global clothing_df
    try:
        data = request.get_json()
        if data is None:
            raise ValueError("No JSON data received")

        if clothing_df.empty or 'Id' not in clothing_df.columns:
            next_id = 1
        else:
            next_id = int(clothing_df['Id'].max()) + 1

        data['Id'] = next_id

        new_row = pd.DataFrame([data])
        clothing_df = pd.concat([clothing_df, new_row], ignore_index=True)
        save_clothing_items(clothing_df)
        return jsonify({'success': True, 'message': 'Clothing added successfully', 'id': next_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Server error: {str(e)}"}), 500

# Endpoint for retrieving all clothing items
@app.route('/get_clothing', methods=['GET'])
def get_clothing():
    return jsonify(clothing_df.to_dict(orient='records'))

@app.route('/delete_clothing/<int:item_id>', methods=['DELETE'])
def delete_clothing(item_id):
    global clothing_df
    try:
        if (clothing_df['Id'] == item_id).any():
            clothing_df = clothing_df[clothing_df['Id'] != item_id].reset_index(drop=True)
            save_clothing_items(clothing_df)
            return jsonify({'success': True, 'message': 'Clothing item deleted'})
        else:
            raise KeyError("Item ID not found")
    except KeyError:
        return jsonify({'success': False, 'message': 'Item not found'}), 404

@app.route('/update_clothing', methods=['POST'])
def update_clothing():
    global clothing_df
    data = request.json
    item_id = int(data['Id'])
    try:
        row_index = clothing_df[clothing_df['Id'] == item_id].index[0]
        for key, value in data.items():
            if key != 'Id':
                clothing_df.at[row_index, key] = value
        save_clothing_items(clothing_df)
        return jsonify({'success': True, 'message': 'Item updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/choose_outfit', methods=['POST'])
def choose_outfit():
    try:
        outfit = request.json
        save_chosen_outfit(outfit, CHOSEN_OUTFITS_CSV_PATH)
        return jsonify({'success': True, 'message': 'Outfit chosen successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/exclude_outfit', methods=['POST'])
def exclude_outfit():
    try:
        outfit = request.json
        save_excluded_outfit(outfit, EXCLUDED_OUTFITS_CSV_PATH)
        return jsonify({'success': True, 'message': 'Outfit excluded successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

EVENTS_CSV_PATH = 'data1/events.csv'

def load_events():
    try:
        df = pd.read_csv(EVENTS_CSV_PATH)
        df['start'] = pd.to_datetime(df[['year', 'month', 'day', 'hour', 'minute']])
        events = df[['description', 'start']].to_dict(orient='records')
        return events
    except Exception as e:
        print(f"Error loading events: {e}")
        return []

@app.route('/api/events', methods=['GET'])
def get_events():
    events = load_events()
    return jsonify(events)

def save_events(events_df):
    try:
        events_df.to_csv(EVENTS_CSV_PATH, index=False)
        print("Events saved successfully")
    except Exception as e:
        print(f"Failed to save events: {e}")

@app.route('/add_event', methods=['POST'])
def add_event():
    event = request.json
    try:
        event_datetime = datetime.fromisoformat(event['start'].rstrip('Z'))
        new_event = pd.DataFrame([{
            'year': event_datetime.year,
            'month': event_datetime.month,
            'day': event_datetime.day,
            'hour': event_datetime.hour,
            'minute': event_datetime.minute,
            'description': event['title']
        }])
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        events_df = pd.concat([events_df, new_event], ignore_index=True)
        events_df.to_csv(EVENTS_CSV_PATH, index=False)
        return jsonify({'success': True, 'message': 'Event added successfully'})
    except Exception as e:
        print(f"Failed to add event: {e}")
        return jsonify({'success': False, 'message': f"Failed to add event: {str(e)}"})

@app.route('/update_event', methods=['POST'])
def update_event():
    event = request.json
    try:
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        mask = events_df['description'] == event['oldTitle']
        if mask.any():
            events_df.loc[mask, 'description'] = event['title']
            events_df.to_csv(EVENTS_CSV_PATH, index=False)
            return jsonify({'success': True, 'message': 'Event updated successfully'})
        else:
            return jsonify({'success': False, 'message': 'Event not found'})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Failed to update event: {str(e)}"})

@app.route('/delete_event', methods=['POST'])
def delete_event():
    event = request.json
    try:
        events_df = pd.read_csv(EVENTS_CSV_PATH)
        initial_length = len(events_df)
        events_df = events_df[events_df['description'] != event['title']]
        if len(events_df) < initial_length:
            events_df.to_csv(EVENTS_CSV_PATH, index=False)
            return jsonify({'success': True, 'message': 'Event deleted successfully'})
        else:
            return jsonify({'success': False, 'message': 'Event not found'})
    except Exception as e:
        return jsonify({'success': False, 'message': f"Failed to delete event: {str(e)}"})


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Set your OpenAI API key directly. It's better to use an environment variable for production use.
openai.api_key = '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'

@app.route('/generate_outfits', methods=['POST'])
def generate_outfits_endpoint():
    try:
        data = request.json
        if not data:
            raise ValueError("No JSON data received")

        event_descriptions = data.get('event_descriptions')
        city_name = data.get('city_name', 'Beirut')

        logging.info(f"Event Descriptions: {event_descriptions}")
        logging.info(f"City Name: {city_name}")

        # Load clothing dataset
        clothing_items = read_clothing_dataset()
        logging.info("Clothing items loaded")

        # Filter recommended clothing items
        recommended_items = filter_recommended_clothing_items(clothing_items, event_descriptions, city_name)
        if recommended_items is None or recommended_items.empty:
            return jsonify({"success": False, "message": "No recommendations found."})

        logging.info("Recommended items found")

        # Categorize clothing items
        dresses, jackets, tops, bottoms = categorize_clothing_items(recommended_items)
        logging.info("Categorized clothing items")

        # Generate outfits and get the top 5
        outfits = generate_outfits(dresses, jackets, tops, bottoms, clothing_items, EXCLUDED_OUTFITS_CSV_PATH, CHOSEN_OUTFITS_CSV_PATH)
        logging.info("Generated top 5 outfits")

        # Get the first recommended outfit
        first_outfit = outfits[0]
        first_outfit_str = json.dumps(first_outfit)  
        print(first_outfit)
        print("First outfit: " + first_outfit_str)
        formatted_outfit = format_outfit(first_outfit)
        print("Formatted outfit: " + formatted_outfit)

        time.sleep(1)
        send_to_arduino(formatted_outfit)
        logging.info("Sent the first outfit to the Arduino")

        # Text-to-speech for the top outfit
        text_to_speech(formatted_outfit)

        return jsonify({"success": True, "outfits": outfits})
    except openai.error.RateLimitError as e:
        logging.error(f"Rate limit error: {e}")
        return jsonify({"success": False, "message": "Rate limit exceeded. Please try again later."}), 429
    except Exception as e:
        logging.error(f"Error in generate_outfits_endpoint: {e}")
        return jsonify({"success": False, "message": f"Server error: {str(e)}"}), 500

arduino_port = 'COM5'  # Replace with the correct port
baudrate = 9600
timeout = 0.01  # Set timeout to 10 milliseconds (0.01 seconds)

def open_serial_connection(port, baudrate, timeout):
    try:
        ser = serial.Serial(port, baudrate, timeout=timeout)
        # Wait for the Arduino to reset
        time.sleep(2)
        return ser
    except serial.SerialException as e:
        print(f"Failed to connect to {port}: {e}")
        sys.exit(1)

def send_to_arduino(data):
    try:
        # Open the serial connection
        ser = open_serial_connection(arduino_port, baudrate, timeout)
        print("Data sent to LCD: ", data)
        # Add a delay to ensure the Arduino and LCD are fully initialized
        time.sleep(5)
        # Send data to the Arduino
        ser.write(data.encode())
        print(f"Sending to Arduino: {data}")  # Debugging statement
        # Wait a bit to ensure the data is sent and processed
        time.sleep(0.5)
        ser.close()
    except Exception as e:
        logging.error(f"Failed to send data to Arduino: {e}")

def format_outfit(outfit):
    # Format the outfit dictionary into the desired string format
    parts = []
    top = outfit.get("Top")
    bottom = outfit.get("Bottom")
    jacket = outfit.get("Jacket")
    dress = outfit.get("Dress")
    
    if top:
        parts.append(f"Top {top}")
    if bottom:
        parts.append(f"Bottom {bottom}")
    if jacket:
        parts.append(f"Jacket {jacket}")
    if dress:
        parts.append(f"Dress {dress}")
    
    return ", ".join(parts)


if __name__ == '__main__':
    # Ensure the data directory exists
    os.makedirs('data1', exist_ok=True)
    app.run(debug=True)