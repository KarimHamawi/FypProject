import pyttsx3

def text_to_speech(text):
    # Initialize the converter
    engine = pyttsx3.init()

    # Set properties before adding anything to speak
    engine.setProperty('rate', 170)    # Speed percent (can go over 100)
    engine.setProperty('volume', 1)  # Volume 0-1

    # Adding things to say
    engine.say(text) 

    # Blocks while processing all the currently queued commands
    engine.runAndWait()

# if __name__ == "__main__":
#     text = "I suggest red shirt with ID 1 and blue skirt with ID 2."
#     text_to_speech(text)
