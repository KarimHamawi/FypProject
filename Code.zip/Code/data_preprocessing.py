import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from scipy.sparse import hstack

# Function to load data from a specific file path
def load_data():
    file_path = r"C:\Users\PC\Desktop\Data Science Project\Code\data1\Dataset.xlsx"
    df = pd.read_excel(file_path)
    return df

# Preprocessing for numerical features
numeric_features = ['Temp', 'Humidity']
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

# Preprocessing for categorical features
categorical_features = ['Type', 'Color', 'Fabric', 'Season Suitability', 'Style', 'Condition', 'Weather Cond', 'Type of Event']
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Combining preprocessing for numerical and categorical data
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)
    ],
    remainder='passthrough'
)

# Function to preprocess data and return preprocessed features along with the target
def preprocess_data(data, target_column):
    features = data.drop(target_column, axis=1)
    target = data[target_column]

    preprocessed_features = preprocessor.fit_transform(features)

    # Converting to DataFrame from sparse matrix
    preprocessed_features_df = pd.DataFrame(preprocessed_features.toarray(), columns=get_feature_names(preprocessor))

    return preprocessed_features_df, target

# Helper function to get feature names from ColumnTransformer
def get_feature_names(column_transformer):
    feature_names = []

    # Loop through each transformer in the ColumnTransformer
    for transformer_name, transformer, original_features in column_transformer.transformers_:
        if transformer == 'passthrough':
            feature_names.extend(original_features)
        elif hasattr(transformer, 'get_feature_names_out'):
            if transformer_name == 'cat':  # Specifically handling the categorical transformer
                names = transformer.get_feature_names_out(original_features)
                # Strip the transformer prefix (e.g., 'cat__Type_Shirt' becomes 'Type_Shirt')
                names = [name.split('__')[-1] for name in names]
                feature_names.extend(names)
            else:
                names = transformer.get_feature_names_out(original_features)
                feature_names.extend(names)
        else:
            names = [f"{f}" for f in original_features]  # For other transformers, no prefix added
            feature_names.extend(names)

    return feature_names


