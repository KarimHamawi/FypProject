document.addEventListener('DOMContentLoaded', function () {
    var selectedDate = null;
    var isRemovingEvent = false;  // Flag to track if we are in event removal mode

    // Initialize the calendar
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        selectable: true,
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('/api/events')
            .then(response => response.json())
            .then(events => {
                const formattedEvents = events.map(event => ({
                    title: event.description,
                    start: new Date(event.start),
                    allDay: true
                }));
                successCallback(formattedEvents);
            })
            .catch(error => {
                console.error('Error fetching events:', error);
                failureCallback(error);
            });
        },
        dateClick: function (info) {
            selectedDate = info.dateStr; // Update selected date
            updateButtonStates(); // Update button states based on selected date
        },
        eventClick: function(info) {
            console.log("Event clicked");
            if (isRemovingEvent) {
                if (confirm("Are you sure you want to delete this event: " + info.event.title + "?")) {
                    fetch('/delete_event', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({title: info.event.title})
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            info.event.remove();
                            alert('Event deleted successfully!');
                        } else {
                            alert(data.message);
                        }
                        isRemovingEvent = false;  // Reset the flag after removing the event
                    })
                    .catch(error => console.error('Error deleting event:', error));
                }
            } else {
                let newTitle = prompt('Edit the event title:', info.event.title);
                if (newTitle && newTitle !== info.event.title) {
                    fetch('/update_event', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({oldTitle: info.event.title, title: newTitle})
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            info.event.setProp('title', newTitle);
                            alert('Event updated successfully!');
                        } else {
                            alert(data.message);
                        }
                    })
                    .catch(error => console.error('Error updating event:', error));
                }
            }
        }
    });
    calendar.render();

    // Add event listeners to buttons
    var addEventBtn = document.getElementById('add-event-btn');
    var removeEventBtn = document.getElementById('remove-event-btn');

    addEventBtn.addEventListener('click', function () {
        if (selectedDate) {
            addCalendarEvent(calendar, selectedDate); // Add event on button click
        } else {
            alert('Please select a date to add an event.');
        }
    });

    removeEventBtn.addEventListener('click', function () {
        if (calendar.getEvents().length > 0) {
            isRemovingEvent = true;  // Set the flag to indicate we are in 'event removal' mode
            alert('Please click on an event to remove it.');
        } else {
            alert("There are no events to remove.");
        }
    });

    function updateButtonStates() {
        let events = calendar.getEvents();
        addEventBtn.disabled = !selectedDate; // Disable add button if no date is selected
        removeEventBtn.disabled = events.length === 0; // Disable remove button if there are no events
    }

    function addCalendarEvent(calendar, date) {
        let title = prompt('Enter event title:');
        if (title) {
            let event = {
                title: title,
                start: new Date(date).toISOString()  // Ensure ISO string format
            };
            fetch('/add_event', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(event)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    calendar.addEvent({
                        title: title,
                        start: date,
                        allDay: true
                    });
                    alert('Event added!');
                } else {
                    alert('Failed to add event: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
    }

    function handleEventResponse(data, info, actionType) {
        if (data.success) {
            if (actionType === 'delete') {
                info.event.remove();
                alert('Event deleted successfully!');
            } else if (actionType === 'update') {
                alert('Event updated successfully!');
            }
        } else {
            alert(data.message);
        }
    }

    calendar.render();

    document.getElementById('generate-outfits').addEventListener('click', function() {
        var selectedDateEvents = calendar.getEvents().filter(event => event.startStr === selectedDate);
        if (selectedDateEvents.length === 0) {
            alert('No events on selected date to generate outfits for.');
            return;
        }
    
        const eventDescriptions = selectedDateEvents.map(event => event.title);
    
        fetch('/generate_outfits', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({event_descriptions: eventDescriptions})
        })
        .then(response => response.json())
        .then(data => {
            if (data.success === false) {
                alert(data.message);
            } else {
                displayOutfits(data.outfits);  // Pass only the outfits array to displayOutfits
            }
        })
        .catch(error => {
            console.error('Error generating outfits:', error);
            alert('Failed to generate outfits. Please try again later.');
        });
    });    
    
    function chooseOutfit(outfit) {
        fetch('/choose_outfit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(outfit)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Outfit chosen successfully!');
            } else {
                alert('Failed to choose outfit: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }    

    function excludeOutfit(outfit) {
        fetch('/exclude_outfit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(outfit)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Outfit excluded successfully!');
            } else {
                alert('Failed to exclude outfit: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    document.getElementById('close-outfit-modal').addEventListener('click', function() {
        document.getElementById('outfit-modal').style.display = 'none';
    });

    function displayOutfits(outfits) {
        let container = document.getElementById('outfits-container');
        container.innerHTML = ''; // Clear previous results
    
        outfits.forEach(outfit => {
            let div = document.createElement('div');
            div.className = 'outfit-item';
            let outfitText = 'Outfit: ';
            for (let [key, value] of Object.entries(outfit)) {
                outfitText += `${key}: ${value}, `;
            }
            div.textContent = outfitText.slice(0, -2); // Remove trailing comma and space
            
            // Create a container for the buttons
            let buttonContainer = document.createElement('div');
            buttonContainer.className = 'button-container';
            
            // Create a button to select the outfit
            let button = document.createElement('button');
            button.textContent = 'Choose this outfit';
            button.className = 'choose-outfit-button';
            button.onclick = function() {
                chooseOutfit(outfit);
            };
            buttonContainer.appendChild(button);
    
            // Create a red X button to exclude the outfit
            let excludeButton = document.createElement('button');
            excludeButton.textContent = 'X';
            excludeButton.className = 'exclude-button';
            excludeButton.onclick = function() {
                excludeOutfit(outfit);
            };
            buttonContainer.appendChild(excludeButton);
            
            div.appendChild(buttonContainer);
            container.appendChild(div);
        });
    
        document.getElementById('outfit-modal').style.display = 'block';
    }
    
    document.getElementById('close-outfit-modal').addEventListener('click', function() {
        document.getElementById('outfit-modal').style.display = 'none';
    });       

    function closeOutfitModal() {
        document.getElementById('outfit-modal').style.display = 'none';
    }

    document.getElementById('close-outfit-modal').addEventListener('click', closeOutfitModal);

    function addClothingItem() {
        let form = document.getElementById("clothing-form");
        let formData = {
            Type: form.elements['Type'].value,
            Color: form.elements['Color'].value,
            Fabric: form.elements['Fabric'].value,
            'Season Suitability': form.elements['Season Suitability'].value,
            Style: form.elements['Style'].value,
            Condition: form.elements['Condition'].value
        };

        fetch('/add_clothing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                formData['Id'] = data.id;  // Use the Id returned from the server
                addRowToTable(formData); // Add row to table with the new ID
                alert(data.message);
            } else {
                alert('Failed to add clothing item: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
        form.reset(); // Reset the form after submission

    }

    function addRowToTable(item, index) {
        let table = document.getElementById("clothing-table").querySelector("tbody");
        let row = document.createElement("tr");

        const fields = ['Id', 'Type', 'Color', 'Fabric', 'Season Suitability', 'Style', 'Condition'];

        fields.forEach(field => {
            let cell = document.createElement("td");
            cell.textContent = item[field];
            row.appendChild(cell);
        });

        let actionCell = document.createElement("td");
        let editBtn = document.createElement("button");
        editBtn.textContent = "Edit";
        editBtn.onclick = function() {
            editClothingItem(row, index);
        };
        actionCell.appendChild(editBtn);

        let removeBtn = document.createElement("button");
        removeBtn.textContent = "Remove";
        removeBtn.onclick = function() {
            deleteClothingItem(item['Id'], row);
        };
        actionCell.appendChild(removeBtn);

        row.appendChild(actionCell);
        table.appendChild(row);
    }

    function deleteClothingItem(itemId, row) {
        fetch('/delete_clothing/' + itemId, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                row.remove();
                alert('Item removed successfully.');
            } else {
                alert('Failed to remove item: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    function editClothingItem(row) {
        let cells = row.getElementsByTagName("td");
        let currentValues = {
            Id: cells[0].textContent,
            Type: cells[1].textContent,
            Color: cells[2].textContent,
            Fabric: cells[3].textContent,
            'Season Suitability': cells[4].textContent,
            Style: cells[5].textContent,
            Condition: cells[6].textContent
        };

        // Define options for each dropdown menu
        const options = {
            Type: ["Jacket", "Dress", "Shirt", "Skirt", "Trousers"],
            Color: ["White", "Blue", "Black", "Red", "Green", "Yellow", "Orange", "Purple"],
            Fabric: ["Cotton", "Wool", "Polyester", "Silk"],
            'Season Suitability': ["Spring", "Summer", "Fall", "Winter"],
            Style: ["Casual", "Vintage", "Athletic", "Formal"],
            Condition: ["New", "Used", "Worn"]
        };

        let modal = document.createElement("div");
        modal.style.position = "fixed";
        modal.style.top = "50%";
        modal.style.left = "50%";
        modal.style.transform = "translate(-50%, -50%)";
        modal.style.backgroundColor = "white";
        modal.style.padding = "20px";
        modal.style.zIndex = "1000";
        modal.style.width = "500px";
        modal.style.boxSizing = "border-box";
        modal.style.maxWidth = "90%";

        let formHtml = `<form id="edit-form">
            ${createSelectHTML('Type', options.Type, currentValues.Type)}
            ${createSelectHTML('Color', options.Color, currentValues.Color)}
            ${createSelectHTML('Fabric', options.Fabric, currentValues.Fabric)}
            ${createSelectHTML('Season Suitability', options["Season Suitability"], currentValues["Season Suitability"])}
            ${createSelectHTML('Style', options.Style, currentValues.Style)}
            ${createSelectHTML('Condition', options.Condition, currentValues.Condition)}
            <button type="button" onclick="submitEdit(this.form, '${row.rowIndex}')">Save Changes</button>
            <button type="button" onclick="this.closest('div').remove()">Cancel</button>
        </form>`;

        modal.innerHTML = formHtml;
        document.body.appendChild(modal);
    }

    function createSelectHTML(name, options, currentValue) {
        let optionsHTML = options.map(option =>
            `<option value="${option}" ${option === currentValue ? 'selected' : ''}>${option}</option>`
        ).join('');

        return `<label>${name.charAt(0).toUpperCase() + name.slice(1)}:
                <select name="${name}">${optionsHTML}</select>
                </label><br>`;
    }

    window.submitEdit = function(form, rowIndex) {
        let table = document.getElementById("clothing-table");
        let row = table.rows[rowIndex];
        let selects = form.querySelectorAll("select");
        let updatedData = {
            Id: row.cells[0].textContent,
        };

        Array.from(selects).forEach((select, index) => {
            let fieldName = select.name;
            updatedData[fieldName] = select.value;
            row.cells[index + 1].textContent = select.value;
        });

        fetch('/update_clothing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Update successful');
            } else {
                console.error('Failed to update', data.message);
            }
        })
        .catch(error => console.error('Error updating item', error));

        document.body.removeChild(form.parentNode);
    };

    console.log("Setting up event listeners");
    document.getElementById("clothing-form").addEventListener("submit", function(event) {
        console.log("Form submitted");
        event.preventDefault();
        addClothingItem();
    });

    fetchClothingItems();

    function fetchClothingItems() {
        fetch('/get_clothing')
        .then(response => response.json())
        .then(data => {
            data.forEach((item, index) => addRowToTable(item, index));
        })
        .catch(error => console.error('Error fetching clothing items:', error));
    }
});
