import openai
import random
import logging
from cachetools import cached, TTLCache

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Set your OpenAI API key directly. It's better to use an environment variable for production use.
openai.api_key = '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'

# Create a cache with a TTL (time-to-live) of 300 seconds (5 minutes) and a maximum size of 100 items
cache = TTLCache(maxsize=100, ttl=300)

@cached(cache)
def classify_event_with_gpt3(event_text):
    prompt = f"""Classify the following event:\n'{event_text}'\nOptions: 
    ['Sports Activity', 'Formal Event', 'Casual Outing'] AND ONLY GIVE ME TWO WORDS STRICTLY. 
    ONLY THE LABEL. IT HAS TO BE 'Sports Activity', 'Formal Event', or 'Casual Outing'!!). 
    One of these three is all you will respond with."""
    
    logging.info(f"Calling GPT-3 for event classification with prompt: {prompt}")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=3,
            temperature=0.7
        )
        
        content = response.choices[0].message['content'].strip()
        if content == "Casual Out":
            content = "Casual Outing"
        
        valid_responses = ['Sports Activity', 'Formal Event', 'Casual Outing']
        if content not in valid_responses:
            content = random.choice(valid_responses)
        
        logging.info(f"Received GPT-3 response: {content}")
        return content
    except openai.error.RateLimitError as e:
        logging.error(f"Rate limit error: {e}")
        return "Rate limit error"

@cached(cache)
def classify_event_with_gpt3_2(event_text2):
    prompt = f"""Classify the following weather:\n'{event_text2}'\nOptions: 
    ['Windy', 'Snowy', 'Rainy', 'Sunny', 'Cloudy'] AND ONLY GIVE ME TWO OR LESS WORDS STRICTLY. 
    ONLY THE LABEL. IT HAS TO BE 'Windy', 'Snowy', 'Rainy', 'Cloudy', OR 'Sunny'.
    One of these five is all you will respond with."""
    
    logging.info(f"Calling GPT-3 for weather classification with prompt: {prompt}")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=3,
            temperature=0.7
        )
        
        content = response.choices[0].message['content'].strip()
        
        valid_responses = ['Windy', 'Snowy', 'Rainy', 'Sunny', 'Cloudy']
        if content not in valid_responses:
            content = random.choice(valid_responses)
        
        logging.info(f"Received GPT-3 response: {content}")
        return content
    except openai.error.RateLimitError as e:
        logging.error(f"Rate limit error: {e}")
        return "Rate limit error"

if __name__ == '__main__':
    print(classify_event_with_gpt3_2("Clouds"))
