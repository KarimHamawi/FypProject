import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
from data_preprocessing import load_data, preprocess_data, preprocessor, get_feature_names

def train_naive_bayes(X_train, y_train, model_path='optimized_nb_model.pkl', var_smoothing=1e-9):
    """Train Gaussian Naive Bayes model with specific var_smoothing."""
    nb = GaussianNB(var_smoothing=var_smoothing)  # Initialize GaussianNB with specific smoothing
    nb.fit(X_train, y_train)  # Fit model on training data
    joblib.dump(nb, model_path)  # Save the model to disk
    return nb

def evaluate_model():
    """Evaluate the Naive Bayes model on the test dataset."""
    data = load_data()  # Load data
    X, y = preprocess_data(data, 'Recommend')  # Preprocess data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  # Split data
    
    model = train_naive_bayes(X_train, y_train)  # Train model
    joblib.dump(preprocessor, 'preprocessor.pkl')  # Save preprocessor

    predictions = model.predict(X_test)  # Predict on test data
    print("Classification Report:\n", classification_report(y_test, predictions, zero_division=0))
    print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
    print("Accuracy:", accuracy_score(y_test, predictions))

def make_recommendations(raw_input_features):
    """Generate predictions for new data using the trained model."""
    model = joblib.load('optimized_nb_model.pkl')  # Load trained model
    preprocessor = joblib.load('preprocessor.pkl')  # Load preprocessor

    input_features = preprocessor.transform(raw_input_features)  # Transform raw input features
    feature_names = get_feature_names(preprocessor)  # Get feature names from preprocessor

    input_features_df = pd.DataFrame(input_features.toarray(), columns=feature_names)  # Create DataFrame
    recommendation = model.predict(input_features_df)  # Predict using the model
    return recommendation

if __name__ == "__main__":
    evaluate_model()  # Run evaluation
